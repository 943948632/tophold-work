(function ()
{
    'use strict';

    angular
        .module('app.components.charts.c3')
        .controller('C3Controller', C3Controller);

    function C3Controller()
    {
        var vm = this;

        // Data

        // Methods

        //////////

    }

})();