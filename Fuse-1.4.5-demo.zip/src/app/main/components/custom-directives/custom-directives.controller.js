(function ()
{
    'use strict';

    angular
        .module('app.components.custom-directives')
        .controller('CustomDirectivesController', CustomDirectivesController);

    /** @ngInject */
    function CustomDirectivesController()
    {
        // Data

        // Methods

        //////////
    }
})();