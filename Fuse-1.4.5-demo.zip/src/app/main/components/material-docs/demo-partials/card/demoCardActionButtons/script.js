
angular.module('cardDemo2', ['ngMaterial'])

.controller('AppCtrl', function($scope) {
  $scope.imagePath = 'assets/angular-material-assets/img/washedout.png';
});
