function timeConverter(UNIX_timestamp) {
	var a = new Date(UNIX_timestamp * 1000);
	var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	var year = a.getFullYear();
	var month = months[a.getMonth()];
	var date = a.getDate();
	var hour = a.getHours();
	var min = a.getMinutes();
	var sec = a.getSeconds();
	var time = date + ',' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
	return time;
}

if(Datafeeds == undefined) {
	var Datafeeds = {}
	Datafeeds.UDFCompatibleDatafeed = function() {};
}

Datafeeds.QuotesPulseUpdater = function(datafeed) {}

Datafeeds.DataPulseUpdater = function(datafeed) {
	console.log("Attaching ADVFNStreamingUpdater");
	this._datafeed = datafeed;
	this._subscribers = {};
	this._dataProviders = {};
	this._providers = {};
}

Datafeeds.DataPulseUpdater._connections = {};

Datafeeds.DataPulseUpdater.prototype.drawBar = function(guid, bar) {
	var subscribers = this._subscribers;

	if(!subscribers.hasOwnProperty(guid)) {
		//console.log("Cancelling data for subscriber");
		return;
	}

	(function(_subscriptionRecord) {
		var listeners = _subscriptionRecord.listeners;

		for(var i = 0; i < listeners.length; ++i) {
			listeners[i](bar);
		}
	})(subscribers[guid]);
}

Datafeeds.DataPulseUpdater.prototype.unsubscribeDataListener = function(listenerGUID) {
	this._datafeed._logMessage("Unsubscribing " + listenerGUID);
	htmlstFeedCreator.unsubscribe(Datafeeds.DataPulseUpdater._connections[listenerGUID]);
	delete this._subscribers[listenerGUID];
	delete this._providers[listenerGUID];
}

Datafeeds.DataPulseUpdater.prototype.subscribeDataListener = function(symbolInfo, resolution, newDataCallback, listenerGUID) {
	this._datafeed._logMessage("Subscribing " + listenerGUID);
	if(!this._subscribers.hasOwnProperty(listenerGUID)) {

		this._subscribers[listenerGUID] = {
			symbolInfo: symbolInfo,
			resolution: resolution,
			lastBarTime: NaN,
			listeners: []
		};

		var provider = this.getDataProviderBySymbol(symbolInfo.ticker, resolution);
		provider.setUpdater(this);
	}

	this._subscribers[listenerGUID].listeners.push(newDataCallback);
}

Datafeeds.DataPulseUpdater.prototype.getDataProviderBySymbol = function(symbol, resolution) {
	var id = symbol + "," + resolution;

	if(!this._providers[id]) {
		this._providers[id] = new DataProvider(symbol, resolution);
	}

	return this._providers[id];
}

function DataProvider(symbol, resolution) {
	this._currentBar = new PriceSample();
	console.log("Attaching DataProvider to symbol " + symbol + " for resolution " + resolution);

	var that = this;
	var guid = symbol + ',' + resolution;

	htmlstFeedCreator.add("===", DataSource.TIME.dataSource.channel).on('data', function(value, flags, clientState) {});

	var i = 0;
	var fields = [];
	if(resolution == "D" || resolution == "M" || resolution == "W") {
		console.log("Connecting to daily data");
		fields[i++] = [DataSource.LAST_CHANGE_TIME.dataSource.channel, 'time'];
		fields[i++] = [DataSource.VOLUME.dataSource.channel, 'volume'];
		fields[i++] = [DataSource.OPEN_PRICE.dataSource.channel, 'open'];
		fields[i++] = [DataSource.HIGH_PRICE.dataSource.channel, 'high'];
		fields[i++] = [DataSource.LOW_PRICE.dataSource.channel, 'low'];
		fields[i++] = [DataSource.CUR_PRICE.dataSource.channel, 'close'];
	} else {
		console.log("Connecting to intraday data");
		fields[i++] = [DataSource.LAST_CHANGE_TIME.dataSource.channel, 'time'];
		fields[i++] = [DataSource.PERIOD_1_TOTAL_VOLUME.dataSource.channel, 'volume'];
		fields[i++] = [DataSource.PERIOD_1_CUR_OPEN.dataSource.channel, 'open'];
		fields[i++] = [DataSource.PERIOD_1_CUR_HIGH.dataSource.channel, 'high'];
		fields[i++] = [DataSource.PERIOD_1_CUR_LOW.dataSource.channel, 'low'];
		fields[i++] = [DataSource.PERIOD_1_CUR_CLOSE.dataSource.channel, 'close'];
	}

	for(i = 0; i < fields.length; i++) {
		var dataField = fields[i][0];
		var candleProperty = fields[i][1];

		(function(dataFieldParam, candlePropertyParam) {
			htmlstFeedCreator.add(symbol, dataFieldParam).on('data', function(value, flags, clientState) {
				that.handleL1Data(candlePropertyParam, value, resolution, guid);
			});
		})(dataField, candleProperty);
	}

	Datafeeds.DataPulseUpdater._connections[guid] = htmlstFeedCreator.sendRequests();
};

DataProvider.prototype.setUpdater = function(updater) {
	this._updater = updater;
};

DataProvider.prototype.getCurrentValue = function() {
	return this._currentValue;
};

DataProvider.prototype.getTimestamp = function() {
	return this._timestamp;
};

DataProvider.prototype.handleL1Data = function(field, value, resolution, guid) {
	//console.log(field+": "+value);

	switch(field) {
		case 'open':
			this._setOpenPrice(parseFloat(value));
			break;
		case 'high':
			this._setHighPrice(parseFloat(value));
			break;
		case 'low':
			this._setLowPrice(parseFloat(value));
			break;
		case 'close':
			this._setCurrentPrice(parseFloat(value));
			break;
		case 'volume':
			this._setVolume(parseInt(value.split(',').join(''), 10));
			break;
		case 'time':
			this._setTimestamp(parseInt(value, 10), resolution, guid);
			break;
	}

	this._updateCurrentBar();
	if(this._currentBar.getTimestamp() == undefined)
		return;

	var bar = this._currentBar.toJSON();
	if(typeof bar != "object")
		return;

	//console.log(this._currentBar.toJSON());
	this._updater.drawBar(guid, bar);
};

/**
 * @private
 */
DataProvider.prototype._updateCurrentBar = function() {
	this._currentBar.setOpen(this._open);
	this._currentBar.setHigh(this._high);
	this._currentBar.setLow(this._low);
	this._currentBar.setClose(this._currentValue);
	this._currentBar.setVolume(this._volume);
};

/**
 * @private
 */
DataProvider.prototype._setOpenPrice = function(open) {
	if(isNaN(open))
		return;

	this._open = open;
};

/**
 * @protected
 */
DataProvider.prototype._setHighPrice = function(high) {
	if(isNaN(high))
		return;

	this._high = high;
};

/**
 * @protected
 */
DataProvider.prototype._setLowPrice = function(low) {
	if(isNaN(low))
		return;

	this._low = low;
};

/**
 * @protected
 */
DataProvider.prototype._setVolume = function(volume) {
	if(isNaN(volume))
		return;

	this._volume = volume;
};
/**
 * @protected
 */
DataProvider.prototype._setCurrentPrice = function(cur) {
	if(isNaN(cur))
		return;

	this._currentValue = cur;
};

/**
 * @private
 */
DataProvider.prototype._setTimestamp = function(timestamp, resolution, guid) {
	var period = 60;

	if(resolution == "D" || resolution == "M" || resolution == "W") {
		period = 60 * 60 * 24;
	}

	this._timestamp = parseInt(timestamp / period) * period * 1000;

	if(this._currentBar.getTimestamp() == undefined) {
		this._currentBar.setTimestamp(this._timestamp);
		return;
	}

	while(this._timestamp > this._currentBar.getTimestamp()) {
		this._open = this._currentValue;
		this._high = this._currentValue;
		this._low = this._currentValue;
		this._volume = 0;

		var time = this._currentBar.getTimestamp() + period * 1000;
		this._currentBar.setTimestamp(time);
		this._currentBar.setOpen(this._currentValue);
		this._currentBar.setHigh(this._currentValue);
		this._currentBar.setLow(this._currentValue);
		this._currentBar.setClose(this._currentValue);
		this._currentBar.setVolume(0);

		var bar = this._currentBar.toJSON();
		if(typeof bar != "object")
			return;

		this._updater.drawBar(guid, bar);
	}
};

/* @constructor
 * @param {number} timestamp
 * @param {number} localTimestamp
 * @param {number} [open]
 * @param {number} [high]
 * @param {number} [low]
 * @param {number} [close]
 * @param {number} [volume]
 */
function PriceSample() {
	this._timestamp = undefined;
	this._localTimestamp = undefined;
	this._open = undefined;
	this._high = undefined;
	this._low = undefined;
	this._close = undefined;
	this._volume = 0;
};

PriceSample.prototype.getLocalisedTimestamp = function() {
	return this._localTimestamp;
};

PriceSample.prototype.setTimestamp = function(timestamp) {
	this._timestamp = timestamp;
};

PriceSample.prototype.setOpen = function(open) {
	this._open = open;
};

PriceSample.prototype.setHigh = function(high) {
	this._high = high;
};

PriceSample.prototype.setLow = function(low) {
	this._low = low;
};

PriceSample.prototype.setClose = function(close) {
	this._close = close;
};

PriceSample.prototype.setVolume = function(volume) {
	this._volume = volume;
};

PriceSample.prototype.getOpen = function() {
	return this._open;
};

PriceSample.prototype.getHigh = function() {
	return this._high;
};

PriceSample.prototype.getLow = function() {
	return this._low;
};

PriceSample.prototype.getClose = function() {
	return this._close;
};

PriceSample.prototype.getTimestamp = function() {
	return this._timestamp;
};

PriceSample.prototype.toJSON = function() {
	var open = this._open;
	var high = this._high;
	var low = this._low;
	var close = this._close;
	var volume = this._volume;

	if(close == undefined && open == undefined) {
		return false;
	}
	if(close == undefined) {
		close = open;
	}
	if(open == undefined) {
		open = close;
	}
	if(high == undefined) {
		high = close;
	}

	if(low == undefined) {
		low = close;
	}

	if(volume == undefined) {
		volume = 0;
	}

	high = Math.max(open, close, high);
	low = Math.min(open, close, low);

	return {
		'time': this._timestamp,
		'open': open,
		'high': high,
		'low': low,
		'close': close,
		'volume': volume
	};
};

Datafeeds.UDFCompatibleDatafeed.prototype.calculateHistoryDepth = function(period, resolutionBack, intervalBack) {
	switch(period) {
		case "1D":
			return {
				resolutionBack: 'D',
				intervalBack: 7
			};
		case '1W':
		case '1M':
		case '3M':
			return {
				resolutionBack: 'M',
				intervalBack: 6
			};
		case '6M':
		case '12M':
			return {
				resolutionBack: 'M',
				intervalBack: 12
			};
		default:
			return {
				resolutionBack: 'D',
				intervalBack: 1
			};
	}
};

Datafeeds.UDFCompatibleDatafeed.prototype.getBarsWrapper = Datafeeds.UDFCompatibleDatafeed.prototype.getBars;

Datafeeds.UDFCompatibleDatafeed.prototype._requestsPending = 0;

Datafeeds.UDFCompatibleDatafeed.prototype.myBars = [];
Datafeeds.UDFCompatibleDatafeed.prototype.startTime = undefined;
Datafeeds.UDFCompatibleDatafeed.prototype.resolution = undefined;
Datafeeds.UDFCompatibleDatafeed.prototype.symbol = undefined;

Datafeeds.UDFCompatibleDatafeed.prototype.getBars = function(symbolInfo, resolution, rangeStartDate, rangeEndDate, onDataCallback, onErrorCallback) {
	console.log("Requesting getBars for resolution: " + resolution + " from:" + timeConverter(rangeStartDate) + " = " + rangeStartDate + " to:" + timeConverter(rangeEndDate));

	// Set the symbol to the global variable
	if(window.TRADING_VIEW) {
		TRADING_VIEW.setSymbol(symbolInfo);
	}

	if(rangeStartDate < 473385600)
		rangeStartDate = 473385600; /// 01 Jan 1985 (I couldn't see any companies with history older than that, so am capping it here)

	if(this.resolution != resolution || this.symbol != symbolInfo.ticker) {
		this.symbol = symbolInfo.ticker;
		this.resolution = resolution;
		this.myBars = [];
		this.startTime = undefined;
	}

	if(this.startTime != undefined) {
		if(rangeEndDate > this.startTime)
			rangeEndDate = this.startTime;
	}

	//	console.log("Requesting getBars for resolution: "+resolution+" from:"+rangeStartDate+" to:"+rangeEndDate);

	this.startTime = rangeStartDate;

	switch(resolution) {
		case "D":
		case "W":
		case "M":
			var max_ts_chunk = 2 * 12 * 30 * 24 * 60 * 60; //2 years
			break;
		default:
			var max_ts_chunk = 24 * 60 * 60; // 1 day
			break;
	}

	var that = this;
	var pushBars = function() {
		that.myBars.sort(function(a, b) {
			if(a.time < b.time)
				return -1;
			else if(a.time > b.time)
				return 1;
			return 0;
		});
		onDataCallback(that.myBars);
	}

	var myCallback = function(bars) {
		that._requestsPending--;
		that.myBars = that.myBars.concat(bars);

		if(that._requestsPending == 0)
			pushBars();
	}

	var myErrorCallback = function(error) {
		that._requestsPending--;
		if(that._requestsPending == 0) {
			if(that.myBars.length == 0) {
				onErrorCallback(error);
			} else {
				pushBars();
			}
		}
	}

	if(rangeEndDate <= rangeStartDate) {
		if(that.myBars.length == 0) {
			onErrorCallback("no bars to send");
		} else {
			pushBars();
		}
		return;
	}

	var count = 0;
	var start;
	var end = rangeEndDate;
	while(true) {
		start = end - max_ts_chunk;
		if(start <= rangeStartDate)
			start = rangeStartDate;

		//console.log("Requesting getBars chunks for resolution: "+resolution+" from:"+start+" to:"+end);
		this._requestsPending++;
		this.getBarsWrapper(symbolInfo, resolution, start, end, myCallback, myErrorCallback);
		end = start - 1;

		if(start <= rangeStartDate)
			break;

		if(count++ > 100) {
			console.log('BREAK AT 100');
			break;
		}
	}
}

// Create a global variable to be able to be called
//var TRADING_VIEW = {
//	symbol: null
//};
//
//TRADING_VIEW.setSymbol = function(symbol) {
//	this.symbol = symbol;
//	if(ADVFNSymbolInfo != undefined) {
//		ADVFNSymbolInfo.setFeedSymbol(symbol.ticker, 'chart');
//	}
//};
//
//TRADING_VIEW.getSymbol = function() {
//	return this.symbol;
//};